#ifndef __CPU_H_
#define __CPU_H_

int GetNumCPUs();
int CoreAffinitize(int cpu);

#endif /* __CPU_H_ */
