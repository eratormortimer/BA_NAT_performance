# Section title

## Frame title

Stuff

- Stuff X
- Stuff Y

## Frame 2

Point 1

Point 2

## Frame 3 ##

![Figure caption](figures/example.pdf)

