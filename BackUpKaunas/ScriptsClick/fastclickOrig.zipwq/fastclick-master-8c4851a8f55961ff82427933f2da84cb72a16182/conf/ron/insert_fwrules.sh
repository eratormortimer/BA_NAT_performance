#!/bin/tcsh

./insert_fwrules_real.sh fxp0 sudo


