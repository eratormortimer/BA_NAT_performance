#ifndef __PROXY_TCP_H_
#define __PROXY_TCP_H_
		
struct tcp_proxy {

	int socket_id;

	int client_id;
	int server_id;

};

#endif
