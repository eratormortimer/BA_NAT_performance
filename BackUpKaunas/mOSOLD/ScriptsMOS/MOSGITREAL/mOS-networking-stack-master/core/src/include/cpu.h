#ifndef __CPU_H_
#define __CPU_H_

int GetNumCPUs();

#endif /* __CPU_H_ */
